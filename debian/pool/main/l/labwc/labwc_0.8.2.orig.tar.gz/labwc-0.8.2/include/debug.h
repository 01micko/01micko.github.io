/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef LABWC_DEBUG_H
#define LABWC_DEBUG_H

struct server;

void debug_dump_scene(struct server *server);

#endif /* LABWC_DEBUG_H */
