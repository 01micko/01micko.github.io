#ifndef SIZE_H
#define SIZE_H

// To be used with sfdo_{str,mem}build_add()
#define SFDO_SIZE1 ((size_t)1)

#endif
