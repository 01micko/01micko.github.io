/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef UPDATE_H
#define UPDATE_H
#include <gtk/gtk.h>

void update(GtkWidget *widget, gpointer data);

#endif /* UPDATE_H */
