sfwbar-appmenu
##############

##############################
Sfwbar Application menu module
##############################

:Copyright: GPLv3+
:Manual section: 1

Filename: appmenu.so

Requires: none

SYNOPSIS
========

The application menu module creates and maintains the applications menu object.
This module has no triggers, actions or expression functions. The application
menu is named `app_menu_system`.
