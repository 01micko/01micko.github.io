#ifndef TEST_LIB_H
#define TEST_LIB_H

bool test_cmp_files(const char *filename_actual, const char *filename_expect);

#endif /* TEST_LIB_H */
