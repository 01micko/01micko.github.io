/* SPDX-License-Identifier: GPL-2.0-only */
#ifndef STACK_LANG_H
#define STACK_LANG_H
#include <gtk/gtk.h>

struct state;

void stack_lang_init(struct state *state, GtkWidget *stack);

#endif /* STACK_LANG_H */
