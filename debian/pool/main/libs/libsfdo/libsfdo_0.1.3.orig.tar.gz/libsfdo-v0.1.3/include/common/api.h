#ifndef API_H
#define API_H

#define SFDO_API __attribute__((visibility("default")))

#endif
