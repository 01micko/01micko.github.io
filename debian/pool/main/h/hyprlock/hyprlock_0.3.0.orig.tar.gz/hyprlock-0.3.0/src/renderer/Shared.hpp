#pragma once
#include "Texture.hpp"

struct SPreloadedAsset {
    CTexture texture;
    bool     ready = false;
};