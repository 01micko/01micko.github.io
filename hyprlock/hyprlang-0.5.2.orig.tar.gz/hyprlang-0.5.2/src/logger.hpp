#pragma once

namespace Logger {}