#pragma once

#include <string>
#include <optional>

std::string absolutePath(const std::string&, const std::string&);
