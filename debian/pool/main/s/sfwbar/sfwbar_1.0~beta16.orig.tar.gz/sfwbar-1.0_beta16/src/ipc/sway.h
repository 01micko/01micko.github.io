#ifndef __SWAY_IPC_H__
#define __SWAY_IPC_H__

#include "scanner.h"

void sway_ipc_init ( void );
void sway_ipc_client_init ( ScanFile *file );

#endif
