import { writeSearchIndex } from '../utils/search-serde'

async function main() {
  await writeSearchIndex()
}

main()
